import React from 'react';import {NavLink} from 'react-router-dom';import {useCart} from '../context/CartContext.jsx';import './Header.scss';
export default function Header(){const {count}=useCart();return <header className="site-header"><div className="shell nav">
 <NavLink className="brand" to="/">Б<span>●</span>РЩ <small>маркет</small></NavLink>
 <nav aria-label="Головна навігація"><NavLink to="/">Каталог</NavLink><NavLink to="/cart">Кошик <b className="badge">{count}</b></NavLink><NavLink to="/orders">Замовлення</NavLink><NavLink to="/admin">Керування</NavLink></nav>
 </div></header>}
