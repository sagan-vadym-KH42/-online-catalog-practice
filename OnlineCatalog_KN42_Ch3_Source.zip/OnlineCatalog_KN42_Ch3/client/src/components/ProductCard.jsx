import React from 'react';import {money} from '../utils/format.mjs';import './ProductCard.scss';
export default function ProductCard({product,onAdd}){return <article className="product-card"><div className="product-cover" aria-hidden="true"><span>◈</span></div>
 <div className="card-content"><span className="eyebrow">Каталог / #{product.id}</span><h3>{product.name}</h3><p>{product.description||'Практичний товар для щоденного використання.'}</p>
 <div className="price">{money(product.priceKop)}</div><div className="card-actions"><span className={product.stock?'instock':'outstock'}>{product.stock?'В наявності: '+product.stock:'Немає в наявності'}</span><button disabled={!product.stock} onClick={()=>onAdd(product)}>+ У кошик</button></div></div></article>}
