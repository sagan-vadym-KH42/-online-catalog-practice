import React from 'react';import './Footer.scss';
export default function Footer(){return <footer className="footer shell">© 2026 Борщ Маркет · Навчальний проєкт коледжу «Оптіма» · Демонстраційний каталог без онлайн-оплати</footer>}
