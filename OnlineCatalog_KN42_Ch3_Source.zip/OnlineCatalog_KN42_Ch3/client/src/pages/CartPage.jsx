import React,{useEffect,useState} from 'react';import {Link,useNavigate} from 'react-router-dom';import {useCart} from '../context/CartContext.jsx';import {useServices} from '../context/ServicesContext.jsx';import {money} from '../utils/format.mjs';
import CartItem from '../components/CartItem.jsx';import CheckoutForm from '../components/CheckoutForm.jsx';import Feedback from '../components/Feedback.jsx';
export default function CartPage(){const c=useCart(),{api}=useServices(),navigate=useNavigate();const [busy,setBusy]=useState(false),[error,setError]=useState(''),[stock,setStock]=useState({});
 useEffect(()=>{let alive=true;Promise.all(c.items.map(x=>api.getProduct(x.id).then(p=>[x.id,p.stock]).catch(()=>[x.id,0]))).then(pairs=>{if(alive)setStock(Object.fromEntries(pairs))});return()=>{alive=false}},[api,c.items.length]);
 async function submit(name){setBusy(true);setError('');try{
 // Revalidate stock just before checkout; the server remains authoritative.
 const latest=await Promise.all(c.items.map(x=>api.getProduct(x.id)));
 for(const item of c.items){const p=latest.find(x=>x.id===item.id);if(!p||p.stock<item.quantity)throw new Error(`Недостатньо товару «${item.name}». Оновіть кількість.`);}
 const result=await api.createOrder(name,c.orderItems);c.clear();navigate('/success/'+result.id);
 }catch(err){setError(err.message)}finally{setBusy(false)}}
 if(!c.items.length)return <><h1>Ваш кошик</h1><Feedback empty/><Link className="btn" to="/">Перейти до каталогу</Link></>;
 return <><h1>Ваш кошик</h1><div className="cart-layout"><section className="panel">{c.items.map(item=><CartItem key={item.id} item={item} stock={stock[item.id]} onQuantity={c.changeQuantity} onRemove={c.remove}/>)}<h2 className="cart-total">Разом: {money(c.totalKop)}</h2></section><div><CheckoutForm loading={busy} onSubmit={submit}/>{error&&<Feedback error={error}/>}</div></div></>}
