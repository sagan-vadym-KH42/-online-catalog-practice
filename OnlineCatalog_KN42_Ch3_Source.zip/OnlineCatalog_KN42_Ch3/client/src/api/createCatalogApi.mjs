/** HTTP client; fetch can be injected for isolated tests. */
export function createCatalogApi({baseUrl='http://localhost:3000/api/v1',fetchImpl=globalThis.fetch}={}) {
 const base=baseUrl.replace(/\/$/,'');
 async function request(path,{method='GET',body,signal}={}){
  let response;
  try {response=await fetchImpl(base+path,{method,headers:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal});}
  catch(err){if(err?.name==='AbortError')throw err;throw new Error('Не вдалося підключитися до сервера. Перевірте запуск API на порту 3000.');}
  if(response.status===204)return null;
  let payload;try{payload=await response.json();}catch{throw new Error('Сервер повернув некоректний JSON.');}
  if(!response.ok)throw new Error(payload?.error?.message || `Помилка HTTP ${response.status}`);
  return payload;
 }
 const numeric=(id)=>encodeURIComponent(String(id));
 return Object.freeze({
  getCategories:({signal}={})=>request('/categories',{signal}).then(x=>x.data),
  createCategory:(name)=>request('/categories',{method:'POST',body:{name}}).then(x=>x.data),
  deleteCategory:(id)=>request('/categories/'+numeric(id),{method:'DELETE'}),
  getProducts:({search='',categoryId='',limit=50,offset=0,signal}={})=>{
   const params=new URLSearchParams({limit:String(limit),offset:String(offset)});
   if(search.trim())params.set('search',search.trim());
   if(categoryId)params.set('categoryId',String(categoryId));
   return request('/products?'+params.toString(),{signal});
  },
  getProduct:(id)=>request('/products/'+numeric(id)).then(x=>x.data),
  createProduct:(data)=>request('/products',{method:'POST',body:data}).then(x=>x.data),
  updateProduct:(id,data)=>request('/products/'+numeric(id),{method:'PATCH',body:data}).then(x=>x.data),
  deleteProduct:(id)=>request('/products/'+numeric(id),{method:'DELETE'}),
  getOrders:()=>request('/orders').then(x=>x.data),
  getOrder:(id)=>request('/orders/'+numeric(id)).then(x=>x.data),
  createOrder:(customerName,items)=>request('/orders',{method:'POST',body:{customerName,items}}).then(x=>x.data)
 });
}
