import React from 'react';
import {Routes,Route,Navigate} from 'react-router-dom';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import CatalogPage from './pages/CatalogPage.jsx';
import CartPage from './pages/CartPage.jsx';
import OrdersPage from './pages/OrdersPage.jsx';
import OrderSuccessPage from './pages/OrderSuccessPage.jsx';
import AdminPage from './pages/AdminPage.jsx';
export default function App(){return <><Header/><main className="layout" id="main"><Routes>
 <Route path="/" element={<CatalogPage/>}/><Route path="/cart" element={<CartPage/>}/>
 <Route path="/orders" element={<OrdersPage/>}/><Route path="/success/:orderId" element={<OrderSuccessPage/>}/>
 <Route path="/admin" element={<AdminPage/>}/><Route path="*" element={<Navigate to="/" replace/>}/>
 </Routes></main><Footer/></>}
