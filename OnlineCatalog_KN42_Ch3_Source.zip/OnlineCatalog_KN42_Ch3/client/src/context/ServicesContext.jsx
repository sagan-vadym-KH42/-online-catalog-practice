import React,{createContext,useContext,useMemo} from 'react';
import {createCatalogApi} from '../api/createCatalogApi.mjs';
const Context=createContext(null);
/** Client-side DI: all components receive the same API interface from the provider. */
export function ServicesProvider({children,apiOverride}){
 const api=useMemo(()=>apiOverride ?? createCatalogApi({baseUrl:import.meta.env.VITE_API_URL || 'http://localhost:3000/api/v1'}),[apiOverride]);
 return <Context.Provider value={{api}}>{children}</Context.Provider>;
}
export function useServices(){const val=useContext(Context);if(!val)throw new Error('ServicesProvider is missing');return val;}
