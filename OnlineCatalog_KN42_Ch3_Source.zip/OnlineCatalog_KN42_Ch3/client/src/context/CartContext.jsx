import React,{createContext,useState,useEffect,useContext,useCallback,useMemo} from 'react';
import {STORAGE_KEY,normalizeCart,addItem,setQuantity,totalKop,toOrderItems} from '../utils/cart.mjs';
const CartContext=createContext(null);
function initial(){try{return normalizeCart(JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]'));}catch{return [];}}
export function CartProvider({children}){
 const [items,setItems]=useState(initial);
 useEffect(()=>{try{localStorage.setItem(STORAGE_KEY,JSON.stringify(items));}catch{/* blocked storage */}},[items]);
 const add=useCallback((product)=>setItems(x=>addItem(x,product)),[]);
 const changeQuantity=useCallback((id,quantity,stock)=>setItems(x=>setQuantity(x,id,quantity,stock)),[]);
 const remove=useCallback(id=>setItems(x=>x.filter(y=>y.id!==id)),[]);
 const clear=useCallback(()=>setItems([]),[]);
 const value=useMemo(()=>({items,add,changeQuantity,remove,clear,totalKop:totalKop(items),orderItems:toOrderItems(items),count:items.reduce((n,x)=>n+x.quantity,0)}),[items,add,changeQuantity,remove,clear]);
 return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
export function useCart(){const x=useContext(CartContext);if(!x)throw new Error('CartProvider missing');return x;}
