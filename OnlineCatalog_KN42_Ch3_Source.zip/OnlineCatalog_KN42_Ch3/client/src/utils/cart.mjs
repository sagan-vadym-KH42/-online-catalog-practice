export const STORAGE_KEY='optyma_catalog_cart_v3';
function safeInt(x){return Number.isSafeInteger(x)&&x>=0;}
export function normalizeCart(value){
 if(!Array.isArray(value))return [];
 const ids=new Set();const result=[];
 for(const x of value){if(!x || !safeInt(x.id)||x.id===0 || !safeInt(x.quantity)||x.quantity===0 || !safeInt(x.priceKop)||typeof x.name!=='string'||ids.has(x.id))continue;
  result.push({id:x.id,quantity:Math.min(x.quantity,50),priceKop:x.priceKop,name:x.name.slice(0,140)});ids.add(x.id);}
 return result;
}
export function addItem(cart,product){
 if(!product || !safeInt(product.id)||product.id===0 || !safeInt(product.stock)||product.stock<=0) return cart;
 const count=cart.find(x=>x.id===product.id)?.quantity||0;
 const next=Math.min(product.stock,50,count+1);
 const item={id:product.id,name:product.name,priceKop:product.priceKop,quantity:next};
 return count ? cart.map(x=>x.id===product.id?item:x) : [...cart,item];
}
export function setQuantity(cart,id,quantity,stock){
 if(!Number.isSafeInteger(quantity)||!Number.isSafeInteger(stock))return cart;
 if(quantity<=0)return cart.filter(x=>x.id!==id);
 return cart.map(x=>x.id===id?{...x,quantity:Math.min(quantity,Math.max(0,stock),50)}:x).filter(x=>x.quantity>0);
}
export function totalKop(cart){return cart.reduce((sum,item)=>sum+item.priceKop*item.quantity,0);}
export function toOrderItems(cart){return cart.map(({id,quantity})=>({productId:id,quantity}));}
