export function money(kop){if(!Number.isSafeInteger(kop))return '—';return (kop/100).toLocaleString('uk-UA',{minimumFractionDigits:2,maximumFractionDigits:2})+' грн';}
