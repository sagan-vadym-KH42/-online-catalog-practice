import React from 'react';
import {createRoot} from 'react-dom/client';
import {BrowserRouter} from 'react-router-dom';
import App from './App.jsx';
import {ServicesProvider} from './context/ServicesContext.jsx';
import {CartProvider} from './context/CartContext.jsx';
import './styles/global.scss';
const root=createRoot(document.getElementById('root'));
root.render(<React.StrictMode><ServicesProvider><CartProvider><BrowserRouter><App/></BrowserRouter></CartProvider></ServicesProvider></React.StrictMode>);
