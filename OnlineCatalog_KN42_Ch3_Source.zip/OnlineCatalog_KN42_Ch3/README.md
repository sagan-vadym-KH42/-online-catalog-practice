# Борщ Маркет — онлайн-каталог товарів (частини 1 → 2 → 3)

Навчальна практика з програмування, частина 3. **Саган Вадим Миколайович, КН-42.** ТОВ «Фаховий передвищий коледж «Оптіма».

Це продовження проєкту: частина 1 — Python CLI + JSON; частина 2 — Node.js/Express + SQLite/Sequelize REST API; частина 3 — React + SCSS клієнт.

## Стек та структура
- `server/` — незмінений API з частини 2: CRUD `categories`, `products`, `orders`, Swagger на `/docs`.
- `client/` — React 18, React Router 6, Vite, SCSS; окремі компоненти й сторінки; DI через Context Provider.
- `postman/` — колекція запитів до REST API; `docs/` — скріншоти коду, схеми та макет.

## Установлення (Node.js 20+)

У двох терміналах із кореня проєкту:

```bash
cd server
npm install
cp .env.example .env
npm run migrate
npm start
```

```bash
cd client
npm install
cp .env.example .env
npm run dev
```

У Windows для копіювання використовуйте `copy` замість `cp`.

- **React:** http://localhost:5173/
- **Backend:** http://localhost:3000/health
- **Swagger:** http://localhost:3000/docs
- **API URL:** `VITE_API_URL=http://localhost:3000/api/v1` (за замовчуванням).
- Для CORS значення `CORS_ORIGIN` сервера має бути `http://localhost:5173` (налаштовано за замовчуванням).

## Дані для демонстрації
Після запуску сервера створіть через Swagger або curl категорію й товар. Після цього вони з'являться в React каталозі. Приклад (Windows PowerShell — інший синтаксис для curl):

```bash
curl -X POST http://localhost:3000/api/v1/categories -H 'Content-Type: application/json' -d '{"name":"Електроніка"}'
curl -X POST http://localhost:3000/api/v1/products -H 'Content-Type: application/json' -d '{"name":"Навушники","description":"Бездротові","priceKop":129900,"stock":6,"categoryId":1}'
```

**Сторінки**: `/` каталог/пошук/фільтр; `/cart` кошик і оформлення; `/orders` демонстраційний список замовлень; `/success/:orderId` підтвердження; `/admin` керування категоріями й товарами.

**Увага щодо безпеки:** адміністративні API з частини 2 не захищені авторизацією. Не розміщуйте цей проєкт у публічній мережі із реальними даними покупців. Оплата/доставка не реалізовані. Корзина зберігається в `localStorage` (ключ `optyma_catalog_cart_v3`), при купівлі сервер повторно перевіряє кількість.

## Тести

```bash
cd client && npm run test:unit  # автономні тести: працюють без npm install
cd server && npm run test:unit  # 10 unit-тестів частини 2
cd server && npm run test:api   # після npm install: реальна інтеграція API
cd client && npm run build      # після npm install: збірка React + Sass
```

Тести клієнта перевіряють кошик, підрахунок у копійках, контракти HTTP, мережеві помилки. Автоматичні unit-тести НЕ замінюють живий запуск React, Express та E2E у браузері. У середовищі підготовки навчального комплекту npm пакети не вдалося завантажити через відсутність доступу до registry; інтеграцію потрібно виконати на комп'ютері із мережею перед захистом.

## Архітектура DI
`main.jsx → ServicesProvider(createCatalogApi) → useServices()`; сервіс `api` передається через React Context компонентам. Замість реального Fetch API можна ін'єктувати тестовий `fetchImpl`. `CartProvider` забезпечує стан кошика та локальне сховище.

## GitHub
Своє посилання на репозиторій треба додати до звіту після публікації. Не вигадуйте URL і не публікуйте `.env`, SQLite базу, `node_modules/` або особисті дані. Відправляйте вихідний код в один репозиторій (server/ + client/), щоб викладач міг перевірити запуск повного застосунку.
