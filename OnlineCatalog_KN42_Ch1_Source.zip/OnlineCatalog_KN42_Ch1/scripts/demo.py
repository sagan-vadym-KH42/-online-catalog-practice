"""Приклад детермінованого сценарію для демонстрації функцій."""
import tempfile
from pathlib import Path
from catalog.models import format_price
from catalog.service import CatalogService
from catalog.storage import JsonStorage

with tempfile.TemporaryDirectory() as directory:
    svc = CatalogService(JsonStorage(Path(directory) / "demo.json"))
    svc.add_product("Навушники Bluetooth", "Електроніка", 129900, 8, "Бездротові")
    svc.add_product("Термокружка", "Дім", 45000, 12, "Об'єм 350 мл")
    svc.add_product("USB-C кабель", "Електроніка", 29900, 20, "1 метр")
    print("ДЕМОНСТРАЦІЯ КАТАЛОГУ / ЧАСТИНА 1")
    print("ID | Назва | Категорія | Ціна | Залишок")
    for p in svc.list_products():
        print(f"{p.id} | {p.name} | {p.category} | {format_price(p.price_kop)} | {p.stock}")
    print("\nПошук 'Bluetooth':")
    for p in svc.search_products("Bluetooth"):
        print(f"Знайдено товар №{p.id}: {p.name}")
    order = svc.place_order({1: 2, 3: 1})
    print(f"\nЗамовлення №{order['id']} успішно створено")
    print("Сума:", format_price(order["total_kop"]))
    print("Залишок навушників:", svc.get_product(1).stock)
    print("Замовлень збережено:", len(svc.list_orders()))
