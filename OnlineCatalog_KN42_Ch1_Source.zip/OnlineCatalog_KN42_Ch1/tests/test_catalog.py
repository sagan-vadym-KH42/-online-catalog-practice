"""Автоматизовані перевірки основних сценаріїв використання."""
import tempfile
import unittest
from pathlib import Path
from catalog.models import parse_price, format_price
from catalog.service import CatalogService
from catalog.storage import JsonStorage


class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_file = Path(self.tmp.name) / "db.json"
        self.svc = CatalogService(JsonStorage(self.db_file))

    def tearDown(self):
        self.tmp.cleanup()

    def sample(self):
        return self.svc.add_product("Навушники", "Електроніка", 129900, 5, "Bluetooth")

    def test_01_initial_catalog_empty(self):
        self.assertEqual(self.svc.list_products(), [])

    def test_02_add_product(self):
        p = self.sample()
        self.assertEqual((p.id, p.stock), (1, 5))

    def test_03_persist_after_restart(self):
        self.sample()
        second = CatalogService(JsonStorage(self.db_file))
        self.assertEqual(second.get_product(1).name, "Навушники")

    def test_04_search_case_insensitive(self):
        self.sample()
        self.assertEqual(len(self.svc.search_products("bluetooth")), 1)

    def test_05_filter_by_category(self):
        self.sample()
        self.svc.add_product("Чашка", "Дім", 10000, 2)
        self.assertEqual(len(self.svc.list_products("електроніка")), 1)

    def test_06_update_product(self):
        self.sample()
        self.svc.update_product(1, price_kop=99900, stock=3)
        self.assertEqual(self.svc.get_product(1).price_kop, 99900)
        self.assertEqual(self.svc.get_product(1).stock, 3)

    def test_07_delete_product(self):
        self.sample()
        self.svc.delete_product(1)
        self.assertEqual(self.svc.list_products(), [])

    def test_08_prevent_invalid_price(self):
        with self.assertRaises(ValueError):
            self.svc.add_product("А", "Б", -1, 1)

    def test_09_prevent_negative_stock(self):
        with self.assertRaises(ValueError):
            self.svc.add_product("А", "Б", 100, -1)

    def test_10_checkout_changes_stock(self):
        self.sample()
        order = self.svc.place_order({1: 2})
        self.assertEqual(order["total_kop"], 259800)
        self.assertEqual(self.svc.get_product(1).stock, 3)
        self.assertEqual(len(self.svc.list_orders()), 1)

    def test_11_insufficient_stock_atomic(self):
        self.sample()
        self.svc.add_product("Миша", "Електроніка", 35000, 1)
        with self.assertRaises(ValueError):
            self.svc.place_order({1: 1, 2: 3})
        self.assertEqual(self.svc.get_product(1).stock, 5)
        self.assertEqual(len(self.svc.list_orders()), 0)

    def test_12_reject_empty_cart(self):
        with self.assertRaises(ValueError):
            self.svc.place_order({})

    def test_13_price_conversion(self):
        self.assertEqual(parse_price("123,45"), 12345)
        self.assertEqual(format_price(12345), "123.45 грн")

    def test_14_invalid_price_precision(self):
        with self.assertRaises(ValueError):
            parse_price("1.234")

    def test_15_orders_persist(self):
        self.sample()
        self.svc.place_order({1: 1})
        reload_svc = CatalogService(JsonStorage(self.db_file))
        self.assertEqual(reload_svc.list_orders()[0]["id"], 1)

    def test_16_missing_product(self):
        with self.assertRaises(ValueError):
            self.svc.get_product(999)

    def test_17_corrupt_json(self):
        self.db_file.write_text("{bad json", encoding="utf-8")
        with self.assertRaises(ValueError):
            CatalogService(JsonStorage(self.db_file))


if __name__ == "__main__":
    unittest.main()
