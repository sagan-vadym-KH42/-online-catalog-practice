"""Текстове меню застосунку (CLI)."""
from catalog.models import format_price, parse_price
from catalog.service import CatalogService

MENU = """
=== ОНЛАЙН-КАТАЛОГ ТОВАРІВ ===
1. Перелік товарів
2. Пошук товарів
3. Перегляд категорії
4. Додати товар
5. Редагувати товар
6. Видалити товар
7. Додати товар до кошика
8. Переглянути кошик
9. Оформити замовлення
10. Історія замовлень
0. Вихід
"""


def positive_int(message: str, allow_zero: bool = False) -> int:
    raw = input(message).strip()
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError("Потрібно ввести ціле число") from exc
    if value < (0 if allow_zero else 1):
        raise ValueError("Значення має бути невід'ємним" if allow_zero else "Значення має бути додатним")
    return value


def print_products(products: list) -> None:
    if not products:
        print("Товарів не знайдено.")
        return
    print("ID | Найменування | Категорія | Ціна | Залишок")
    for p in products:
        print(f"{p.id} | {p.name} | {p.category} | {format_price(p.price_kop)} | {p.stock}")


def run_cli(service: CatalogService) -> None:
    cart: dict[int, int] = {}
    print("Ласкаво просимо до навчального онлайн-каталогу!")
    while True:
        print(MENU)
        try:
            choice = input("Оберіть дію: ").strip()
            if choice == "0":
                print("До побачення!")
                break
            if choice == "1":
                print_products(service.list_products())
            elif choice == "2":
                print_products(service.search_products(input("Ключове слово: ")))
            elif choice == "3":
                print("Категорії:", ", ".join(service.categories()) or "немає")
                print_products(service.list_products(input("Категорія: ").strip()))
            elif choice == "4":
                name = input("Назва: ")
                category = input("Категорія: ")
                price = parse_price(input("Ціна, грн: "))
                stock = positive_int("Кількість: ", allow_zero=True)
                description = input("Опис (необов'язково): ")
                product = service.add_product(name, category, price, stock, description)
                print(f"Товар №{product.id} додано.")
            elif choice == "5":
                id_ = positive_int("ID товару: ")
                item = service.get_product(id_)
                print("Поточний товар:")
                print_products([item])
                name = input("Нова назва (Enter = без змін): ").strip()
                category = input("Нова категорія (Enter = без змін): ").strip()
                price_text = input("Нова ціна (Enter = без змін): ").strip()
                stock_text = input("Новий залишок (Enter = без змін): ").strip()
                service.update_product(id_, name=name or None, category=category or None,
                                       price_kop=parse_price(price_text) if price_text else None,
                                       stock=int(stock_text) if stock_text else None)
                print("Зміни збережено.")
            elif choice == "6":
                id_ = positive_int("ID товару: ")
                service.delete_product(id_)
                cart.pop(id_, None)
                print("Товар видалено.")
            elif choice == "7":
                id_ = positive_int("ID товару: ")
                qty = positive_int("Кількість: ")
                p = service.get_product(id_)
                if qty + cart.get(id_, 0) > p.stock:
                    raise ValueError("Недостатньо товару на складі")
                cart[id_] = cart.get(id_, 0) + qty
                print(f"У кошику {cart[id_]} шт. товару '{p.name}'.")
            elif choice == "8":
                if not cart:
                    print("Кошик порожній.")
                else:
                    total = 0
                    for id_, qty in cart.items():
                        p = service.get_product(id_)
                        total += p.price_kop * qty
                        print(f"{p.name}: {qty} шт. × {format_price(p.price_kop)}")
                    print("До сплати:", format_price(total))
            elif choice == "9":
                order = service.place_order(cart)
                cart.clear()
                print(f"Замовлення №{order['id']} оформлено. Сума: {format_price(order['total_kop'])}")
            elif choice == "10":
                orders = service.list_orders()
                if not orders:
                    print("Замовлень поки немає.")
                for order in orders:
                    print(f"№{order['id']} | {order['created_at']} | {format_price(order['total_kop'])}")
            else:
                print("Невідомий пункт меню.")
        except (ValueError, EOFError) as exc:
            if isinstance(exc, EOFError):
                break
            print("Помилка:", exc)
