"""Точка входу: python -m catalog."""
import argparse
import logging
from catalog.cli import run_cli
from catalog.storage import JsonStorage
from catalog.service import CatalogService


def main():
    parser = argparse.ArgumentParser(description="Навчальний онлайн-каталог товарів")
    parser.add_argument("--db", default="data/catalog.json", help="Шлях до JSON-бази")
    parser.add_argument("--log", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.log),
                        format="%(asctime)s [%(levelname)s] %(message)s")
    try:
        run_cli(CatalogService(JsonStorage(args.db)))
    except (OSError, ValueError) as exc:
        logging.error("Помилка запуску: %s", exc)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
