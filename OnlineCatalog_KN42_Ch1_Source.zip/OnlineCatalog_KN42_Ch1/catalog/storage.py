"""JSON-сховище з атомарним збереженням та контрольованими помилками."""
import json
import os
import tempfile
from pathlib import Path


class JsonStorage:
    def __init__(self, path: str | Path):
        self.path = Path(path)

    def load(self) -> dict:
        """Читає каталог; створює логічно порожню базу, якщо файл відсутній."""
        if not self.path.exists():
            return {"products": [], "orders": [], "next_product_id": 1, "next_order_id": 1}
        try:
            with self.path.open("r", encoding="utf-8") as file:
                data = json.load(file)
            required = ("products", "orders", "next_product_id", "next_order_id")
            if not isinstance(data, dict) or not all(k in data for k in required):
                raise ValueError("Невідома структура JSON-бази даних")
            return data
        except json.JSONDecodeError as exc:
            raise ValueError("Файл бази даних пошкоджено: неправильний JSON") from exc

    def save(self, data: dict) -> None:
        """Записує спочатку тимчасовий файл, потім атомарно замінює основний."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        filename = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=self.path.parent,
                prefix=".catalog_", suffix=".tmp", delete=False
            ) as file:
                filename = file.name
                json.dump(data, file, ensure_ascii=False, indent=2)
                file.write("\n")
            os.replace(filename, self.path)
        finally:
            if filename is not None and os.path.exists(filename):
                os.remove(filename)
