"""Моделі предметної області та перевірка вхідних даних."""
from dataclasses import dataclass, asdict
from decimal import Decimal, InvalidOperation


def parse_price(value: str) -> int:
    """Перетворює суму в гривнях на ціле число копійок без похибки float."""
    try:
        price = Decimal(str(value).strip().replace(",", "."))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("Ціна має бути числом") from exc
    if not price.is_finite() or price <= 0 or price.as_tuple().exponent < -2:
        raise ValueError("Ціна має бути додатною сумою з точністю до копійок")
    return int(price * 100)


def format_price(price_kop: int) -> str:
    return f"{price_kop / 100:.2f} грн"


@dataclass
class Product:
    id: int
    name: str
    category: str
    price_kop: int
    stock: int
    description: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Product":
        return cls(**data)
