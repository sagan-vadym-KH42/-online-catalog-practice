"""Бізнес-логіка каталогу та оформлення замовлень."""
from datetime import datetime, timezone
import logging
from catalog.models import Product
from catalog.storage import JsonStorage

logger = logging.getLogger(__name__)


class CatalogService:
    def __init__(self, storage: JsonStorage):
        self.storage = storage
        self.db = storage.load()

    def _persist(self) -> None:
        self.storage.save(self.db)

    def list_products(self, category: str | None = None) -> list[Product]:
        products = [Product.from_dict(p) for p in self.db["products"]]
        if category:
            products = [p for p in products if p.category.casefold() == category.casefold()]
        return sorted(products, key=lambda p: p.id)

    def categories(self) -> list[str]:
        return sorted({p.category for p in self.list_products()}, key=str.casefold)

    def search_products(self, query: str) -> list[Product]:
        text = query.strip().casefold()
        if not text:
            return []
        return [p for p in self.list_products() if text in p.name.casefold()
                or text in p.description.casefold() or text in p.category.casefold()]

    def get_product(self, product_id: int) -> Product:
        for p in self.list_products():
            if p.id == product_id:
                return p
        raise ValueError(f"Товар №{product_id} не знайдено")

    def add_product(self, name: str, category: str, price_kop: int,
                    stock: int, description: str = "") -> Product:
        name, category = name.strip(), category.strip()
        if not name or not category:
            raise ValueError("Назва та категорія не можуть бути порожніми")
        if not isinstance(price_kop, int) or price_kop <= 0:
            raise ValueError("Ціна має бути додатною")
        if not isinstance(stock, int) or stock < 0:
            raise ValueError("Кількість не може бути від'ємною")
        product = Product(self.db["next_product_id"], name, category,
                          price_kop, stock, description.strip())
        self.db["products"].append(product.to_dict())
        self.db["next_product_id"] += 1
        self._persist()
        logger.info("Товар створено: id=%s, назва=%s", product.id, product.name)
        return product

    def update_product(self, product_id: int, *, name: str | None = None,
                       category: str | None = None, price_kop: int | None = None,
                       stock: int | None = None) -> Product:
        product = self.get_product(product_id)
        if name is not None:
            if not name.strip():
                raise ValueError("Назва не може бути порожньою")
            product.name = name.strip()
        if category is not None:
            if not category.strip():
                raise ValueError("Категорія не може бути порожньою")
            product.category = category.strip()
        if price_kop is not None:
            if not isinstance(price_kop, int) or price_kop <= 0:
                raise ValueError("Ціна має бути додатною")
            product.price_kop = price_kop
        if stock is not None:
            if not isinstance(stock, int) or stock < 0:
                raise ValueError("Кількість не може бути від'ємною")
            product.stock = stock
        for index, item in enumerate(self.db["products"]):
            if item["id"] == product_id:
                self.db["products"][index] = product.to_dict()
                break
        self._persist()
        logger.info("Товар оновлено: id=%s", product_id)
        return product

    def delete_product(self, product_id: int) -> None:
        self.get_product(product_id)  # підтверджує, що товар існує
        self.db["products"] = [p for p in self.db["products"] if p["id"] != product_id]
        self._persist()
        logger.info("Товар видалено: id=%s", product_id)

    def place_order(self, quantities: dict[int, int]) -> dict:
        """Перевіряє залишки і зберігає замовлення однією операцією."""
        if not quantities:
            raise ValueError("Кошик порожній")
        items, total = [], 0
        for product_id, qty in quantities.items():
            if not isinstance(qty, int) or qty <= 0:
                raise ValueError("Кількість у кошику має бути додатною")
            p = self.get_product(product_id)
            if p.stock < qty:
                raise ValueError(f"Недостатньо товару '{p.name}': доступно {p.stock}")
            amount = p.price_kop * qty
            total += amount
            items.append({"product_id": p.id, "name": p.name, "quantity": qty,
                          "unit_price_kop": p.price_kop, "amount_kop": amount})
        order = {"id": self.db["next_order_id"],
                 "created_at": datetime.now(timezone.utc).isoformat(),
                 "items": items, "total_kop": total}
        # Стан бази змінюється тільки після перевірки всього кошика.
        for product in self.db["products"]:
            if product["id"] in quantities:
                product["stock"] -= quantities[product["id"]]
        self.db["orders"].append(order)
        self.db["next_order_id"] += 1
        self._persist()
        logger.info("Замовлення створено: id=%s, сума=%s коп.", order["id"], total)
        return order

    def list_orders(self) -> list[dict]:
        return list(self.db["orders"])
