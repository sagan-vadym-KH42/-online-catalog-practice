# Онлайн-каталог товарів — серверна частина (ч. 2)

**Автор:** Саган Вадим Миколайович, група КН-42.  
**Навчальний заклад:** Фаховий передвищий коледж «Оптіма».  
**Тема:** Онлайн-каталог товарів (мінімальний e-commerce).  
**Продовження частини 1:** CLI-прототип Python + JSON; частина 2 — серверний API на Node.js. 

## Вимоги
Node.js 20+, npm; доступ до npm для першого встановлення. Сервер використовує SQLite,
тому PostgreSQL встановлювати не потрібно. **SQLite дозволено в загальних умовах завдання ч. 2.**

## Встановлення і запуск

```bash
npm install
cp .env.example .env
npm run migrate
npm start
```

Windows: замість `cp` виконайте `copy .env.example .env`.

- Сервер: `http://localhost:3000`
- Swagger UI: `http://localhost:3000/docs`
- OpenAPI JSON: `http://localhost:3000/openapi.json`
- Перевірка доступності: `GET http://localhost:3000/health`

Сервер також запускає відсутні міграції під час старту.
База SQLite зберігається в `data/catalog.sqlite`; `.env` і БД не публікуються у GitHub.

## REST API

| Ресурс | Метод | Шлях | Призначення |
|---|---|---|---|
| Категорії | GET, POST | `/api/v1/categories` | Список / створення |
| Категорії | GET, PUT, PATCH, DELETE | `/api/v1/categories/:id` | Читання / зміна / видалення |
| Товари | GET, POST | `/api/v1/products` | Список, пошук, фільтр / створення |
| Товари | GET, PUT, PATCH, DELETE | `/api/v1/products/:id` | Читання / зміна / видалення |
| Замовлення | GET, POST | `/api/v1/orders` | Список / оформлення замовлення |
| Замовлення | GET, PUT, PATCH, DELETE | `/api/v1/orders/:id` | Читання / статус / видалення |

Три основні CRUD-ресурси: категорії, товари, замовлення. 
Суми грошей — **цілі числа копійок** (`priceKop`, `totalKop`) для точних обчислень.

### Швидка перевірка через curl

```bash
curl -X POST http://localhost:3000/api/v1/categories -H 'Content-Type: application/json' -d '{"name":"Електроніка"}'
curl -X POST http://localhost:3000/api/v1/products -H 'Content-Type: application/json' -d '{"name":"Навушники","description":"Бездротові","priceKop":129900,"stock":10,"categoryId":1}'
curl -X POST http://localhost:3000/api/v1/orders -H 'Content-Type: application/json' -d '{"customerName":"Покупець","items":[{"productId":1,"quantity":2}]}'
```

### Тестування

```bash
npm run test:unit   # автономні перевірки, навіть без npm install
npm run test:api    # потрібні npm install + SQLite-залежності
npm test            # усі тести
```

Postman: `postman/OnlineCatalog.postman_collection.json`; використовуйте чисту базу для запуску послідовної колекції.
Кожна транзакція замовлення перевіряє запас і зменшує його; видалення замовлення повертає залишок.
Відомі обмеження: локальний прототип; немає аутентифікації, платежів, синхронізації з Python CLI,
 конкурентного захисту від одночасного оформлення замовлень під високим навантаженням.

## Будова проєкту

- `src/routes` — маршрути Express;
- `src/controllers` — HTTP-відповіді та виклики бізнес-логіки;
- `src/services` — бізнес-правила, валідація;
- `src/repositories` — робота з даними через Sequelize;
- `src/db/migrations` — версійні міграції схеми БД;
- `src/models` — сутності та зв’язки;
- `src/di/container.js` — явний DI-контейнер (composition root);
- `src/middleware` — обробка помилок, логування в `app.js`;
- `src/docs/openapi.json` — опис API для Swagger UI;
- `tests` — модульні та інтеграційні перевірки;
- `postman` — послідовна колекція HTTP-запитів.

## GitHub

Після створення власного репозиторію виконайте:

```bash
git init
git add .
git commit -m 'Практика ч.2: REST API каталогу'
git branch -M main
git remote add origin https://github.com/ВАШ_ЛОГІН/online-catalog-backend.git
git push -u origin main
```

**Посилання у звіті необхідно замінити фактичною адресою вашого репозиторію.** 
Авторизацію й завантаження до GitHub потрібно зробити з акаунта студента.
