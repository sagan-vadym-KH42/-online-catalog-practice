const test=require('node:test');const assert=require('node:assert/strict');
// Інтеграційні тести вимагають npm install; ізольована SQLite-база для кожного запуску.
const os=require('os'),fs=require('fs'),path=require('path');
let setupError=null,request,buildDb,migrate,initModels,makeContainer,createApp;
try{
  request=require('supertest');({buildDb}=require('../src/db/connection'));
  ({migrate}=require('../src/db/migrate'));({initModels}=require('../src/models'));
  ({makeContainer}=require('../src/di/container'));({createApp}=require('../src/app'));
}catch(err){setupError=err;}
test('REST API: три CRUD-ресурси, валідація, замовлення і залишки', {skip:setupError ? 'Не встановлені npm-пакети: npm install' : false},async()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'catalog-api-'));
  const db=buildDb(path.join(tmp,'test.sqlite'));
  try{
    await migrate(db);
    const app=createApp(makeContainer(initModels(db),db,{info(){}}));
    assert.equal((await request(app).get('/health')).status,200);
    const category=await request(app).post('/api/v1/categories').send({name:'Одяг'});assert.equal(category.status,201);
    const categoryId=category.body.data.id;
    assert.equal((await request(app).get('/api/v1/categories')).status,200);
    assert.equal((await request(app).get(`/api/v1/categories/${categoryId}`)).status,200);
    assert.equal((await request(app).patch(`/api/v1/categories/${categoryId}`).send({name:'Взуття'})).status,200);
    const prod=await request(app).post('/api/v1/products').send({name:'Кросівки',description:'Опис',priceKop:12000,stock:5,categoryId});assert.equal(prod.status,201);
    const productId=prod.body.data.id;
    assert.equal((await request(app).get('/api/v1/products')).status,200);
    assert.equal((await request(app).get(`/api/v1/products/${productId}`)).status,200);
    assert.equal((await request(app).patch(`/api/v1/products/${productId}`).send({stock:6})).status,200);
    assert.equal((await request(app).post('/api/v1/products').send({name:'X',description:'',priceKop:-1,stock:2,categoryId})).status,422);
    const order=await request(app).post('/api/v1/orders').send({customerName:'Тест',items:[{productId,quantity:2}]});assert.equal(order.status,201);
    assert.equal(order.body.data.totalKop,24000);
    const orderId=order.body.data.id;
    assert.equal((await request(app).get('/api/v1/orders')).status,200);
    assert.equal((await request(app).get(`/api/v1/orders/${orderId}`)).status,200);
    assert.equal((await request(app).patch(`/api/v1/orders/${orderId}`).send({status:'confirmed'})).status,200);
    const remaining=await request(app).get(`/api/v1/products/${productId}`);assert.equal(remaining.body.data.stock,4);
    assert.equal((await request(app).post('/api/v1/orders').send({customerName:'Тест',items:[{productId,quantity:50}]})).status,409);
    assert.equal((await request(app).delete(`/api/v1/categories/${categoryId}`)).status,409);
    assert.equal((await request(app).delete(`/api/v1/orders/${orderId}`)).status,204);
    const restored=await request(app).get(`/api/v1/products/${productId}`);assert.equal(restored.body.data.stock,6);
    assert.equal((await request(app).delete(`/api/v1/products/${productId}`)).status,204);
    assert.equal((await request(app).delete(`/api/v1/categories/${categoryId}`)).status,204);
    assert.equal((await request(app).get('/openapi.json')).status,200);
    assert.equal((await request(app).get('/api/v1/products/99999')).status,404);
  }finally{await db.close();fs.rmSync(tmp,{recursive:true,force:true});}
});
