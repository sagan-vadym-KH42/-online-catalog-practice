const test=require('node:test');const assert=require('node:assert/strict');
const v=require('../src/utils/validation');const {CatalogService}=require('../src/services/catalog');
const {OrdersService}=require('../src/services/orders');
const quiet={info(){}};
test('коректна ціна у копійках і залишок',()=>{
 assert.equal(v.productBody({name:'Товар',description:'',priceKop:100,stock:0,categoryId:1}).priceKop,100);
});
test('від’ємна ціна заборонена',()=>{assert.throws(()=>v.productBody({name:'X',description:'',priceKop:-1,stock:1,categoryId:1}),{status:422});});
test('нецілий залишок заборонено',()=>{assert.throws(()=>v.productBody({name:'X',description:'',priceKop:100,stock:0.5,categoryId:1}),{status:422});});
test('дублікат товару в замовленні заборонено',()=>{assert.throws(()=>v.orderBody({customerName:'А',items:[{productId:1,quantity:1},{productId:1,quantity:2}]}),{status:422});});
test('порожнє замовлення заборонено',()=>{assert.throws(()=>v.orderBody({customerName:'А',items:[]}),{status:422});});
test('невідоме поле заборонено',()=>{assert.throws(()=>v.categoryBody({name:'T',extra:1}),{status:422});});
test('відсутній товар → 404',async()=>{let svc=new CatalogService({get:async()=>({id:1})},{get:async()=>null},quiet);await assert.rejects(svc.getProduct('9'),{status:404});});
test('залежності сервісу можна підміняти',async()=>{
 const c={get:async id=>({id})};const p={create:async d=>({id:3,...d})};
 const svc=new CatalogService(c,p,quiet);
 const x=await svc.addProduct({name:'A',description:'',priceKop:100,stock:2,categoryId:1});assert.equal(x.id,3);
});
test('валідація статусу замовлення',()=>{assert.throws(()=>v.orderUpdate({status:'paid'}),{status:422});assert.equal(v.orderUpdate({status:'confirmed'}).status,'confirmed');});
test('сервіс замовлення передає перевірені дані',async()=>{
 const repo={create:async b=>({id:2,...b})};const svc=new OrdersService(repo,quiet);
 const order=await svc.create({customerName:'  Тест  ',items:[{productId:1,quantity:2}]});
 assert.equal(order.customerName,'Тест');assert.equal(order.items[0].quantity,2);
});
