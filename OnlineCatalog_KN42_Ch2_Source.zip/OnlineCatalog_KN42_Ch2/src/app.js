const express=require('express');const cors=require('cors');const morgan=require('morgan');
const swaggerUi=require('swagger-ui-express');const openapi=require('./docs/openapi.json');
const {catalogRouter}=require('./routes/catalog');const {ordersRouter}=require('./routes/orders');
const {notFound,errorHandler}=require('./middleware/errors');
/** Pure application factory — a separate entrypoint initializes the database. */
function createApp(container){
  const app=express();app.disable('x-powered-by');
  const origin=process.env.CORS_ORIGIN||'http://localhost:5173';
  app.use(cors({origin:origin==='*'?'*':origin}));
  app.use(morgan('combined'));app.use(express.json({limit:'256kb'}));
  app.get('/health',(req,res)=>res.json({status:'ok'}));
  app.get('/openapi.json',(req,res)=>res.json(openapi));
  app.use('/docs',swaggerUi.serve,swaggerUi.setup(openapi));
  app.use('/api/v1',catalogRouter(container.catalog));
  app.use('/api/v1',ordersRouter(container.orders));
  app.use(notFound);app.use(errorHandler);return app;
}
module.exports={createApp};
