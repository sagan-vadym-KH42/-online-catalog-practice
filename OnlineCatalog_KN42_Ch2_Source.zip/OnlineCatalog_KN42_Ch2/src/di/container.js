const {CategoryRepository}=require('../repositories/categories');
const {ProductRepository}=require('../repositories/products');
const {OrderRepository}=require('../repositories/orders');
const {CatalogService}=require('../services/catalog');
const {OrdersService}=require('../services/orders');
/** Composition root: dependencies are injected instead of created inside services. */
function makeContainer(models,sequelize,logger=console){
  const categoryRepo=new CategoryRepository(models);
  const productRepo=new ProductRepository(models);
  const orderRepo=new OrderRepository(models,sequelize);
  return Object.freeze({
    catalog:new CatalogService(categoryRepo,productRepo,logger),
    orders:new OrdersService(orderRepo,logger)
  });
}
module.exports={makeContainer};
