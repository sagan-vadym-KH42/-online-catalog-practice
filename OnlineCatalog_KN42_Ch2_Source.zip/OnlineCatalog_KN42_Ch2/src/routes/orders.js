const {Router}=require('express');const {ordersController}=require('../controllers/orders');const {asyncRoute}=require('../middleware/errors');
function ordersRouter(service){const router=Router(),c=ordersController(service),a=asyncRoute;
 router.get('/orders',a(c.list));router.get('/orders/:id',a(c.get));router.post('/orders',a(c.create));
 router.put('/orders/:id',a(c.update));router.patch('/orders/:id',a(c.update));router.delete('/orders/:id',a(c.remove));
 return router;
}
module.exports={ordersRouter};
