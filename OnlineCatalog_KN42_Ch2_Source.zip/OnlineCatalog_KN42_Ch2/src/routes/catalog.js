const {Router}=require('express');const {catalogController}=require('../controllers/catalog');const {asyncRoute}=require('../middleware/errors');
function catalogRouter(service){
  const router=Router(),c=catalogController(service),a=asyncRoute;
  router.get('/categories',a(c.categories));router.get('/categories/:id',a(c.category));
  router.post('/categories',a(c.addCategory));router.put('/categories/:id',a(c.editCategory));router.patch('/categories/:id',a(c.editCategory));router.delete('/categories/:id',a(c.removeCategory));
  router.get('/products',a(c.products));router.get('/products/:id',a(c.product));
  router.post('/products',a(c.addProduct));router.put('/products/:id',a(c.editProduct));router.patch('/products/:id',a(c.editProduct));router.delete('/products/:id',a(c.removeProduct));
  return router;
}
module.exports={catalogRouter};
