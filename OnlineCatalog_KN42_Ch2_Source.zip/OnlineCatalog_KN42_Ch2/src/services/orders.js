const { AppError }=require('../utils/errors');const v=require('../utils/validation');
class OrdersService {
  constructor(orders,logger=console){this.orders=orders;this.logger=logger;}
  list(){return this.orders.list();}
  async get(id){const r=await this.orders.get(v.id(id));if(!r)throw new AppError('Замовлення не знайдено',404);return r;}
  async create(body){const r=await this.orders.create(v.orderBody(body));this.logger.info(`order.created id=${r.id}`);return r;}
  async update(id,body){return this.orders.update(v.id(id),v.orderUpdate(body));}
  async delete(id){await this.orders.delete(v.id(id));this.logger.info('order.deleted');}
}
module.exports={OrdersService};
