const { AppError }=require('../utils/errors');
const v=require('../utils/validation');
class CatalogService {
  constructor(categories,products,logger=console){this.categories=categories;this.products=products;this.logger=logger;}
  async listCategories(){return this.categories.list();}
  async getCategory(input){const x=await this.categories.get(v.id(input));if(!x)throw new AppError('Категорію не знайдено',404);return x;}
  async addCategory(body){const r=await this.categories.create(v.categoryBody(body));this.logger.info(`category.created id=${r.id}`);return r;}
  async editCategory(id,body){return this.categories.update(v.id(id),v.categoryBody(body,true));}
  async removeCategory(id){await this.categories.delete(v.id(id));this.logger.info('category.deleted');}
  async listProducts(query={}){
    const limit=query.limit===undefined?50:v.id(String(query.limit));
    const offset=query.offset===undefined?0:v.int(Number(query.offset),'offset',0,1000000);
    if(limit>100)throw new AppError('limit має бути від 1 до 100',422);
    const categoryId=query.categoryId===undefined?undefined:v.id(String(query.categoryId));
    const search=query.search===undefined?undefined:v.str(query.search,'search',140);
    return this.products.list({limit,offset,categoryId,search});
  }
  async getProduct(input){const x=await this.products.get(v.id(input));if(!x)throw new AppError('Товар не знайдено',404);return x;}
  async checkCategory(categoryId){if(!await this.categories.get(categoryId))throw new AppError('Категорію не знайдено',404);}
  async addProduct(body){const data=v.productBody(body);await this.checkCategory(data.categoryId);const r=await this.products.create(data);this.logger.info(`product.created id=${r.id}`);return r;}
  async editProduct(id,body){const data=v.productBody(body,true);if(data.categoryId)await this.checkCategory(data.categoryId);return this.products.update(v.id(id),data);}
  async removeProduct(id){await this.products.delete(v.id(id));this.logger.info('product.deleted');}
}
module.exports={CatalogService};
