const {DataTypes}=require('sequelize');
function initModels(sequelize) {
  const common={timestamps:true};
  const Category=sequelize.define('Category',{name:{type:DataTypes.STRING(80),allowNull:false,unique:true}},common);
  const Product=sequelize.define('Product',{
    name:{type:DataTypes.STRING(140),allowNull:false},
    description:{type:DataTypes.TEXT,allowNull:false,defaultValue:''},
    priceKop:{type:DataTypes.INTEGER,allowNull:false},stock:{type:DataTypes.INTEGER,allowNull:false}
  },common);
  const Order=sequelize.define('Order',{
    customerName:{type:DataTypes.STRING(120),allowNull:false},
    status:{type:DataTypes.STRING(20),allowNull:false,defaultValue:'new'},totalKop:{type:DataTypes.INTEGER,allowNull:false}
  },common);
  const OrderItem=sequelize.define('OrderItem',{
    productName:{type:DataTypes.STRING(140),allowNull:false},
    quantity:{type:DataTypes.INTEGER,allowNull:false},priceKop:{type:DataTypes.INTEGER,allowNull:false}
  },common);
  Category.hasMany(Product,{foreignKey:{name:'categoryId',allowNull:false},onDelete:'RESTRICT'});
  Product.belongsTo(Category,{foreignKey:{name:'categoryId',allowNull:false}});
  Order.hasMany(OrderItem,{foreignKey:{name:'orderId',allowNull:false},as:'items',onDelete:'CASCADE'});
  OrderItem.belongsTo(Order,{foreignKey:{name:'orderId',allowNull:false}});
  Product.hasMany(OrderItem,{foreignKey:'productId',onDelete:'SET NULL'});
  OrderItem.belongsTo(Product,{foreignKey:'productId'});
  return {Category,Product,Order,OrderItem};
}
module.exports={initModels};
