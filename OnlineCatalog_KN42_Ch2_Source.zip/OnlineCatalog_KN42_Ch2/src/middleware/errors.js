const {AppError}=require('../utils/errors');
const asyncRoute=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
function notFound(req,res,next){next(new AppError('Маршрут не знайдено',404));}
function errorHandler(err,req,res,next){
  if (err.name==='SequelizeUniqueConstraintError') err=new AppError('Запис із таким значенням вже існує',409);
  else if(err.name==='SequelizeForeignKeyConstraintError')err=new AppError('Порушено зв’язок з іншим записом',409);
  else if(err.name==='SequelizeValidationError')err=new AppError(err.message,422);
  else if(err.type==='entity.parse.failed')err=new AppError('Некоректний формат JSON',400);
  const status=err.status||500;
  if(status>=500) console.error('SERVER ERROR',err);
  res.status(status).json({error:{status,message:status>=500?'Внутрішня помилка сервера':err.message}});
}
module.exports={asyncRoute,notFound,errorHandler};
