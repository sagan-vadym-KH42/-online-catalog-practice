const { AppError } = require('./errors');
const plain = v => v !== null && typeof v === 'object' && !Array.isArray(v);
function str(v, name, max = 140) {
  if (typeof v !== 'string' || !v.trim() || v.trim().length > max)
    throw new AppError(`${name}: очікується непорожній текст до ${max} символів`, 422);
  return v.trim();
}
function int(v, name, min = 0, max = 10000000) {
  if (typeof v !== 'number' || !Number.isSafeInteger(v) || v < min || v > max)
    throw new AppError(`${name}: очікується ціле число від ${min} до ${max}`, 422);
  return v;
}
function id(v) {
  const n = Number(v);
  if (!Number.isSafeInteger(n) || n < 1 || String(n) !== String(v))
    throw new AppError('Некоректний ідентифікатор', 400);
  return n;
}
function allowed(data, keys) {
  if (!plain(data)) throw new AppError('Потрібен об’єкт JSON', 422);
  const bad = Object.keys(data).filter(k => !keys.includes(k));
  if (bad.length) throw new AppError('Невідомі поля: ' + bad.join(', '), 422);
}
function categoryBody(body, partial = false) {
  allowed(body, ['name']);
  if (!partial || Object.hasOwn(body, 'name')) return { name: str(body.name, 'name', 80) };
  throw new AppError('Укажіть хоча б одне поле', 422);
}
function productBody(body, partial = false) {
  const keys = ['name','description','priceKop','stock','categoryId']; allowed(body, keys);
  const x = {};
  if (!partial || Object.hasOwn(body,'name')) x.name = str(body.name,'name',140);
  if (!partial || Object.hasOwn(body,'description')) {
    if (typeof body.description !== 'string' || body.description.length > 1000)
      throw new AppError('description: текст до 1000 символів',422);
    x.description = body.description.trim();
  }
  if (!partial || Object.hasOwn(body,'priceKop')) x.priceKop=int(body.priceKop,'priceKop',1,1000000000);
  if (!partial || Object.hasOwn(body,'stock')) x.stock=int(body.stock,'stock',0,1000000);
  if (!partial || Object.hasOwn(body,'categoryId')) x.categoryId=int(body.categoryId,'categoryId',1);
  if (partial && !Object.keys(x).length) throw new AppError('Укажіть хоча б одне поле',422);
  return x;
}
function orderBody(body) {
  allowed(body,['customerName','items']);
  if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 50)
    throw new AppError('items: від 1 до 50 позицій',422);
  const ids = new Set();
  const items = body.items.map((r)=>{
    allowed(r,['productId','quantity']);
    const productId=int(r.productId,'productId',1);
    const quantity=int(r.quantity,'quantity',1,10000);
    if (ids.has(productId)) throw new AppError('Повторювані productId у замовленні',422);
    ids.add(productId); return {productId,quantity};
  });
  return { customerName:str(body.customerName,'customerName',120), items };
}
function orderUpdate(body) {
  allowed(body,['customerName','status']); const x={};
  if (Object.hasOwn(body,'customerName')) x.customerName=str(body.customerName,'customerName',120);
  if (Object.hasOwn(body,'status')) {
    if (!['new','confirmed'].includes(body.status)) throw new AppError('status: new або confirmed',422);
    x.status=body.status;
  }
  if (!Object.keys(x).length) throw new AppError('Укажіть хоча б одне поле',422);
  return x;
}
module.exports={str,int,id,categoryBody,productBody,orderBody,orderUpdate};
