const {Op}=require('sequelize');const {AppError}=require('../utils/errors');
class ProductRepository {
  constructor(models){this.Product=models.Product;}
  list({search,categoryId,limit=50,offset=0}){
    const where={};if(search)where.name={[Op.like]:`%${search}%`};if(categoryId)where.categoryId=categoryId;
    return this.Product.findAndCountAll({where,limit,offset,order:[['id','ASC']]});
  }
  get(id,options={}){return this.Product.findByPk(id,options);}
  create(data){return this.Product.create(data);}
  async update(id,data){const p=await this.get(id);if(!p)throw new AppError('Товар не знайдено',404);return p.update(data);}
  async delete(id){const p=await this.get(id);if(!p)throw new AppError('Товар не знайдено',404);await p.destroy();}
}
module.exports={ProductRepository};
