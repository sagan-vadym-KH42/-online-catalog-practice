const {AppError}=require('../utils/errors');
class OrderRepository {
  constructor(models,sequelize){this.Order=models.Order;this.OrderItem=models.OrderItem;this.Product=models.Product;this.sequelize=sequelize;}
  list(){return this.Order.findAll({include:[{model:this.OrderItem,as:'items'}],order:[['id','ASC']]});}
  get(id,options={}){return this.Order.findByPk(id,{include:[{model:this.OrderItem,as:'items'}],...options});}
  async create(data){
    return this.sequelize.transaction(async t=>{
      let total=0;const snapshots=[];
      for(const line of data.items){
        const p=await this.Product.findByPk(line.productId,{transaction:t});
        if(!p)throw new AppError(`Товар ${line.productId} не знайдено`,404);
        if(p.stock<line.quantity)throw new AppError(`Недостатній залишок товару ${p.id}`,409);
        total+=p.priceKop*line.quantity;
        if(!Number.isSafeInteger(total)||total>1000000000)throw new AppError('Занадто велика сума замовлення',422);
        snapshots.push({productId:p.id,productName:p.name,priceKop:p.priceKop,quantity:line.quantity});
        await p.decrement('stock',{by:line.quantity,transaction:t});
      }
      const order=await this.Order.create({customerName:data.customerName,totalKop:total,status:'new'},{transaction:t});
      for(const line of snapshots)await this.OrderItem.create({...line,orderId:order.id},{transaction:t});
      return this.get(order.id,{transaction:t});
    });
  }
  async update(id,data){const order=await this.Order.findByPk(id);if(!order)throw new AppError('Замовлення не знайдено',404);await order.update(data);return this.get(id);}
  async delete(id){return this.sequelize.transaction(async t=>{
    const order=await this.get(id,{transaction:t});if(!order)throw new AppError('Замовлення не знайдено',404);
    for(const item of order.items){if(item.productId){const product=await this.Product.findByPk(item.productId,{transaction:t});if(product)await product.increment('stock',{by:item.quantity,transaction:t});}}
    await order.destroy({transaction:t});
  });}
}
module.exports={OrderRepository};
