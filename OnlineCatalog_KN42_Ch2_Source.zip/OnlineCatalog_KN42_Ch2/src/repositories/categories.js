const {AppError}=require('../utils/errors');
class CategoryRepository {
  constructor(models){this.Category=models.Category;this.Product=models.Product;}
  list(){return this.Category.findAll({order:[['id','ASC']]});}
  get(id){return this.Category.findByPk(id);}
  create(data){return this.Category.create(data);}
  async update(id,data){const r=await this.get(id);if(!r)throw new AppError('Категорію не знайдено',404);return r.update(data);}
  async delete(id){const r=await this.get(id);if(!r)throw new AppError('Категорію не знайдено',404);if(await this.Product.count({where:{categoryId:id}}))throw new AppError('Спочатку видаліть або перенесіть товари цієї категорії',409);await r.destroy();}
}
module.exports={CategoryRepository};
