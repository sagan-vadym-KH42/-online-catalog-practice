require('dotenv').config();
const {buildDb}=require('./db/connection');const {migrate}=require('./db/migrate');
const {initModels}=require('./models');const {makeContainer}=require('./di/container');const {createApp}=require('./app');
async function start(){
  const db=buildDb();await migrate(db);
  const app=createApp(makeContainer(initModels(db),db));
  const port=Number(process.env.PORT||3000);
  const server=app.listen(port,()=>console.log(`Каталог API: http://localhost:${port}/docs`));
  const shutdown=()=>server.close(()=>db.close().then(()=>process.exit(0)));
  process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
  return {app,db,server};
}
if(require.main===module)start().catch(e=>{console.error(e);process.exitCode=1;});
module.exports={start};
