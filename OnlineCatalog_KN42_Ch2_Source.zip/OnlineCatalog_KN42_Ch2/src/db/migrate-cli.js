require('dotenv').config();
const {buildDb}=require('./connection'); const {migrate}=require('./migrate');
(async()=>{const db=buildDb();try {await migrate(db);console.log('Міграції виконано');}finally {await db.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
