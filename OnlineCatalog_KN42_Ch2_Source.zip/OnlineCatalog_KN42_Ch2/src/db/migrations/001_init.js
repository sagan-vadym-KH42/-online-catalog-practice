const { DataTypes } = require('sequelize');
async function up(queryInterface) {
  const common={createdAt:{type:DataTypes.DATE,allowNull:false},updatedAt:{type:DataTypes.DATE,allowNull:false}};
  await queryInterface.createTable('Categories',{
    id:{type:DataTypes.INTEGER,primaryKey:true,autoIncrement:true},
    name:{type:DataTypes.STRING(80),allowNull:false,unique:true},...common
  });
  await queryInterface.createTable('Products',{
    id:{type:DataTypes.INTEGER,primaryKey:true,autoIncrement:true},
    name:{type:DataTypes.STRING(140),allowNull:false},
    description:{type:DataTypes.TEXT,allowNull:false,defaultValue:''},
    priceKop:{type:DataTypes.INTEGER,allowNull:false},
    stock:{type:DataTypes.INTEGER,allowNull:false},
    categoryId:{type:DataTypes.INTEGER,allowNull:false,references:{model:'Categories',key:'id'},onUpdate:'CASCADE',onDelete:'RESTRICT'},...common
  });
  await queryInterface.createTable('Orders',{
    id:{type:DataTypes.INTEGER,primaryKey:true,autoIncrement:true},
    customerName:{type:DataTypes.STRING(120),allowNull:false},
    status:{type:DataTypes.STRING(20),allowNull:false,defaultValue:'new'},
    totalKop:{type:DataTypes.INTEGER,allowNull:false},...common
  });
  await queryInterface.createTable('OrderItems',{
    id:{type:DataTypes.INTEGER,primaryKey:true,autoIncrement:true},
    orderId:{type:DataTypes.INTEGER,allowNull:false,references:{model:'Orders',key:'id'},onDelete:'CASCADE',onUpdate:'CASCADE'},
    productId:{type:DataTypes.INTEGER,allowNull:true,references:{model:'Products',key:'id'},onDelete:'SET NULL',onUpdate:'CASCADE'},
    productName:{type:DataTypes.STRING(140),allowNull:false},
    quantity:{type:DataTypes.INTEGER,allowNull:false},
    priceKop:{type:DataTypes.INTEGER,allowNull:false},...common
  });
  await queryInterface.addIndex('Products',['categoryId']);
  await queryInterface.addIndex('OrderItems',['orderId']);
}
module.exports={up};
