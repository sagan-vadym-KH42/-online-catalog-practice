const fs=require('fs'); const path=require('path'); const {Sequelize}=require('sequelize');
function buildDb(storage=process.env.DB_STORAGE || './data/catalog.sqlite') {
  const file=path.resolve(storage); fs.mkdirSync(path.dirname(file),{recursive:true});
  return new Sequelize({dialect:'sqlite',storage:file,logging:false});
}
module.exports={buildDb};
