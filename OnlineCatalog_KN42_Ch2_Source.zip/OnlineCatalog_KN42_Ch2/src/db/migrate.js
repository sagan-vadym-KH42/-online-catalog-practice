const migration=require('./migrations/001_init');
async function migrate(sequelize) {
  await sequelize.authenticate();
  const qi=sequelize.getQueryInterface();
  await qi.createTable('SchemaMigrations',{name:{type:require('sequelize').DataTypes.STRING,primaryKey:true}});
  const [rows]=await sequelize.query('SELECT name FROM SchemaMigrations WHERE name = :name', {replacements:{name:'001_init'}});
  if (!rows.length) {
    // SQLite DDL is performed serially before the API begins accepting requests.
    await migration.up(qi);
    await sequelize.query('INSERT INTO SchemaMigrations (name) VALUES (:name)',{replacements:{name:'001_init'}});
  }
}
module.exports={migrate};
