function catalogController(service){return {
  categories:async(req,res)=>res.json({data:await service.listCategories()}),
  category:async(req,res)=>res.json({data:await service.getCategory(req.params.id)}),
  addCategory:async(req,res)=>res.status(201).json({data:await service.addCategory(req.body)}),
  editCategory:async(req,res)=>res.json({data:await service.editCategory(req.params.id,req.body)}),
  removeCategory:async(req,res)=>{await service.removeCategory(req.params.id);res.status(204).end();},
  products:async(req,res)=>{const result=await service.listProducts(req.query);res.json({data:result.rows,total:result.count});},
  product:async(req,res)=>res.json({data:await service.getProduct(req.params.id)}),
  addProduct:async(req,res)=>res.status(201).json({data:await service.addProduct(req.body)}),
  editProduct:async(req,res)=>res.json({data:await service.editProduct(req.params.id,req.body)}),
  removeProduct:async(req,res)=>{await service.removeProduct(req.params.id);res.status(204).end();}
};}
module.exports={catalogController};
